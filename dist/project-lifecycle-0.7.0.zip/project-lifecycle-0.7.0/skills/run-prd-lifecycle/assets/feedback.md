---
schema_version: 2
artifact_id: feedback-template
artifact_kind: feedback
primary_route: PRD_DELIVERY
project_id_at_creation: sample-project
current_project_id: sample-project
domain_ids: [sample-domain]
knowledge_baseline: replace-with-baseline
relationships: { feedback_ids: [], prd_ids: [], legacy_artifact_refs: [] }
retention_tier: active
reclassified_from_refs: []
obligations: []
---
# 反馈标题

<!-- project-lifecycle:section original_problem -->
## 原始问题
原样记录用户问题，不按解决方案重写。
<!-- /project-lifecycle:section -->

<!-- project-lifecycle:section scenario -->
## 场景
记录问题发生的时间与位置。
<!-- /project-lifecycle:section -->

<!-- project-lifecycle:section expectation -->
## 期望
记录用户期望的结果。
<!-- /project-lifecycle:section -->

<!-- project-lifecycle:section marking -->
## 标记
仅记录标准化状态标记。

> 可选：仅在业务—实现差异得到确认后插入该标记。以下 fenced 示例不会生效。

```text
<!-- project-lifecycle:alignment
schema_version: 1
classification: BUSINESS_IMPLEMENTATION_DIVERGENCE
primary_domain_id: sample-domain
-->
```
<!-- /project-lifecycle:section -->

<!-- project-lifecycle:section coverage -->
## 覆盖
关联已覆盖、延后、拒绝或被替代的具体部分。
<!-- /project-lifecycle:section -->
